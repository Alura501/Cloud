<?php

return [
    'url'      => '{{url}}',
    'index'    => '{{index}}',
    'timezone' => '{{timezone}}',
    'key'      => '{{key}}',
    'language' => '{{language}}',
    'encoding' => 'UTF-8'
];
